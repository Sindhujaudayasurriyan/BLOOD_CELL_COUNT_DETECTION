# cell > cell_dataset
https://universe.roboflow.com/atri-gly8b/cell-p3pcx

Provided by a Roboflow user
License: CC BY 4.0

